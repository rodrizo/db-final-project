﻿using OlimpicosProject.Data;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OlimpicosProject.Controllers
{
    public class CategoriaData
    {
        public DataSet getCategoria()
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_categoria", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", "R"));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Categoria");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }
        public void CategoriaCRUD(Categoria cat, string action)
        {
            Conexion cn = new Conexion();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_categoria", connection))
                    {
                        connection.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", action));
                        if (action == "C")
                        {
                            command.Parameters.Add(new SqlParameter("@nombre", cat.Nombre));
                            command.Parameters.Add(new SqlParameter("@idTipo", cat.IdTipo));
                            command.Parameters.Add(new SqlParameter("@idDeporte", cat.IdDeporte));
                        }
                        else if (action == "U")
                        {
                            command.Parameters.Add(new SqlParameter("@idCategoria", cat.IdCategoria));
                            command.Parameters.Add(new SqlParameter("@nombre", cat.Nombre));
                            command.Parameters.Add(new SqlParameter("@idTipo", cat.IdTipo));
                            command.Parameters.Add(new SqlParameter("@idDeporte", cat.IdDeporte));

                        }
                        else if (action == "D")
                        {
                            command.Parameters.Add(new SqlParameter("@idCategoria", cat.IdCategoria));
                        }
                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //Información referente a categorías (Consultas del enunciado)
        public DataSet getCategoriaInfo(int idCategoria, int option)
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_categorias", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@categoria", idCategoria));
                        command.Parameters.Add(new SqlParameter("@option", option));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Categoria");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }
    }
}


