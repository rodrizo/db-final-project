﻿using OlimpicosProject.Data;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace OlimpicosProject.Controllers
{
    //Creador: Rodney Rizo
    public class CompetidorData
    {
        public DataSet getCompetidores()
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_competidor", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", "R"));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Competidor");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }
        public void CompetidorCRUD(Competidor comp, string action)
        {
            Conexion cn = new Conexion();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_competidor", connection))
                    {
                        connection.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", action));
                        if (action == "C")
                        {
                            command.Parameters.Add(new SqlParameter("@nombre", comp.Nombre));
                            command.Parameters.Add(new SqlParameter("@dpi", comp.DPI));
                            command.Parameters.Add(new SqlParameter("@fecha_nacimiento", comp.Fecha_nacimiento));
                            command.Parameters.Add(new SqlParameter("@idPais", comp.IdPais));
                        }
                        else if (action == "U")
                        {
                            command.Parameters.Add(new SqlParameter("@idCompetidor", comp.IdCompetidor));
                            command.Parameters.Add(new SqlParameter("@nombre", comp.Nombre));
                            command.Parameters.Add(new SqlParameter("@dpi", comp.DPI));
                            command.Parameters.Add(new SqlParameter("@fecha_nacimiento", comp.Fecha_nacimiento));
                            command.Parameters.Add(new SqlParameter("@idPais", comp.IdPais));

                        }
                        else if (action == "D")
                        {
                            command.Parameters.Add(new SqlParameter("@idCompetidor", comp.IdCompetidor));
                        }
                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        //Inserta las marcas de 1 competidor en específico
        public void insertMarca(decimal puntaje, int idCompetidor)
        {
            Conexion cn = new Conexion();
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;

            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = $"INSERT INTO Marca VALUES ({puntaje}, {idCompetidor})";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        //Asigna 1 competidor a 1 equipo
        public void asignarEquipo(int idEquipo, int idCompetidor)
        {
            Conexion cn = new Conexion();
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;

            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = $"INSERT INTO EquipoCompetidor VALUES ({idEquipo}, {idCompetidor})";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        //Asigna 1 medalla a 1 competidor
        public void asignarMedalla(int tipoMedalla, int idCompetidor)
        {
            Conexion cn = new Conexion();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_medallas", connection))
                    {
                        connection.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@tipoMedalla", tipoMedalla));
                        command.Parameters.Add(new SqlParameter("@option", 2));
                        command.Parameters.Add(new SqlParameter("@equipo", null));
                        command.Parameters.Add(new SqlParameter("@competidor", idCompetidor));
                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        //Asigna 1 competidor a 1 categoría
        public void asignarCategoria(int idCategoria, int idCompetidor)
        {
            Conexion cn = new Conexion();
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;

            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = $"INSERT INTO CategoriaCompetidor VALUES ({idCategoria}, {idCompetidor})";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        
        //Información referente a competidores (Consultas del enunciado)
        public DataSet getCompetidorInfo(int idCompetidor, int option)
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_competidores", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@competidor", idCompetidor));
                        command.Parameters.Add(new SqlParameter("@option", option));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Competidor");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }

        //Ranking de países
        public DataSet getRankingCompetidor(int idCompetidor)
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_ranking_competidor", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@competidor", idCompetidor));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Competidor");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }
    }
}
