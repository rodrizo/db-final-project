﻿using OlimpicosProject.Data;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Controllers
{
    public class EquipoData
    {
        public DataSet getEquipos()
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_equipo", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", "R"));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Equipo");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }

        public void EquipoCRUD(Equipo comp, string action)
        {
            Conexion cn = new Conexion();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_equipo", connection))
                    {
                        connection.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", action));
                        if (action == "C")
                        {
                            command.Parameters.Add(new SqlParameter("@nombre", comp.Nombre));
                            command.Parameters.Add(new SqlParameter("@idPais", comp.IdPais));
                        }
                        else if (action == "U")
                        {
                            command.Parameters.Add(new SqlParameter("@idEquipo", comp.IdEquipo));
                            command.Parameters.Add(new SqlParameter("@nombre", comp.Nombre));
                            command.Parameters.Add(new SqlParameter("@idPais", comp.IdPais));

                        }
                        else if (action == "D")
                        {
                            command.Parameters.Add(new SqlParameter("@idEquipo", comp.IdEquipo));
                        }
                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //Asigna 1 medalla a todos los competidores del equipo
        public void asignarMedalla(int tipoMedalla, int idEquipo)
        {
            Conexion cn = new Conexion();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_medallas", connection))
                    {
                        connection.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@tipoMedalla", tipoMedalla));
                        command.Parameters.Add(new SqlParameter("@option", 1));
                        command.Parameters.Add(new SqlParameter("@equipo", idEquipo));
                        command.Parameters.Add(new SqlParameter("@competidor", null));
                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        //Asigna 1 equipo a 1 categoría
        public void asignarCategoria(int idCategoria, int idEquipo)
        {
            Conexion cn = new Conexion();
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;

            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = $"INSERT INTO CategoriaEquipo VALUES ({idCategoria}, {idEquipo})";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
