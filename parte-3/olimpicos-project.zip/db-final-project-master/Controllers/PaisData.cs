﻿using OlimpicosProject.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Controllers
{
    public class PaisData
    {

        //Información referente a países (Consultas del enunciado)
        public DataSet getPaisInfo(int idPais, int option)
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_paises", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@pais", idPais));
                        command.Parameters.Add(new SqlParameter("@option", option));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Pais");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }

        //Ranking de países
        public DataSet getRankingPais(int idPais)
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_ranking_pais", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@pais", idPais));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Pais");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }
    }
}
