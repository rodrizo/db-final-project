﻿using OlimpicosProject.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Controllers
{
    //Clase encargada de retornar data para llenar combo boxes
    public class ComboData
    {
        private Conexion cn = new Conexion();
        private SqlCommand command = new SqlCommand();
        private SqlDataReader reader;

        #region "Retornando tabla con data de países"
        public DataTable getPaises()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = "SELECT * FROM Pais";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    dt.Load(reader);
                    reader.Close();
                    return dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return dt;
            }
        }
        #endregion

        #region "Retornando tabla con data de equipos"
        public DataTable getEquipos()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = "SELECT * FROM Equipo";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    dt.Load(reader);
                    reader.Close();
                    return dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return dt;
            }
        }
        #endregion

        #region "Retornando tabla con data de categorías"
        public DataTable getCategorias()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = "SELECT * FROM Categoria";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    dt.Load(reader);
                    reader.Close();
                    return dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return dt;
            }
        }
        #endregion

        #region "Retornando tabla con data de TipoMarca"
        public DataTable getTipo()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = "SELECT * FROM TipoMarca";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    dt.Load(reader);
                    reader.Close();
                    return dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return dt;
            }
        }
        #endregion

        #region "Retornando tabla con data de deportes"
        public DataTable getDeporte()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = "SELECT * FROM Deporte";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    dt.Load(reader);
                    reader.Close();
                    return dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return dt;
            }
        }
        #endregion

        #region "Retornando tabla con data de competidores"
        public DataTable getCompetidor()
        {
            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    command.Connection = connection;
                    connection.Open();
                    command.CommandText = "SELECT * FROM Competidor";
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                    dt.Load(reader);
                    reader.Close();
                    return dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return dt;
            }
        }
        #endregion
    }
}
