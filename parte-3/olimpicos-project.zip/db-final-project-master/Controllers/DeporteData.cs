﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using OlimpicosProject.Data;
using System.Windows.Forms;
using OlimpicosProject.Models;

namespace OlimpicosProject.Controllers
{
    public class DeporteData
    {
        public DataSet getDeporte()
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_deporte", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", "R"));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Deporte");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }
        public void DeporteCRUD(Deporte dep, string action)
        {
            Conexion cn = new Conexion();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_crud_deporte", connection))
                    {
                        connection.Open();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@action", action));
                        if (action == "C")
                        {
                            command.Parameters.Add(new SqlParameter("@nombre", dep.Nombre));
                           
                        }
                        else if (action == "U")
                        {
                            command.Parameters.Add(new SqlParameter("@idDeporte", dep.IdDeporte));
                            command.Parameters.Add(new SqlParameter("@nombre", dep.Nombre));

                        }
                        else if (action == "D")
                        {
                            command.Parameters.Add(new SqlParameter("@idDeporte", dep.IdDeporte));
                        }
                        command.ExecuteNonQuery();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //Información referente a deportes (Consultas del enunciado)
        public DataSet getDeporteInfo(int idDeporte, int option)
        {
            Conexion cn = new Conexion();
            DataSet ds = new DataSet();
            using (SqlConnection connection = new SqlConnection(cn.conStrin("dbOlimpicos")))
            {
                try
                {
                    using (SqlCommand command = new SqlCommand("sp_deportes", connection))
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new SqlParameter("@deporte", idDeporte));
                        command.Parameters.Add(new SqlParameter("@option", option));
                        adapter.SelectCommand = command;
                        adapter.Fill(ds, "Deporte");

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                return ds;
            }
        }
    }
}