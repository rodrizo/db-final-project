﻿namespace OlimpicosProject
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnCategorias = new System.Windows.Forms.Button();
            this.btnVolt = new System.Windows.Forms.Button();
            this.btnDeportista = new System.Windows.Forms.Button();
            this.btnPaises = new System.Windows.Forms.Button();
            this.btnEquipo = new System.Windows.Forms.Button();
            this.btnDeporte = new System.Windows.Forms.Button();
            this.btnCompetidor = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelDesktopPane = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnRankingP = new System.Windows.Forms.Button();
            this.btnRankingD = new System.Windows.Forms.Button();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            this.panelTitleBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panelMenu.Controls.Add(this.btnRankingD);
            this.panelMenu.Controls.Add(this.btnRankingP);
            this.panelMenu.Controls.Add(this.btnCategorias);
            this.panelMenu.Controls.Add(this.btnVolt);
            this.panelMenu.Controls.Add(this.btnDeportista);
            this.panelMenu.Controls.Add(this.btnPaises);
            this.panelMenu.Controls.Add(this.btnEquipo);
            this.panelMenu.Controls.Add(this.btnDeporte);
            this.panelMenu.Controls.Add(this.btnCompetidor);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(406, 823);
            this.panelMenu.TabIndex = 0;
            // 
            // btnCategorias
            // 
            this.btnCategorias.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCategorias.FlatAppearance.BorderSize = 0;
            this.btnCategorias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCategorias.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCategorias.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCategorias.Location = new System.Drawing.Point(0, 555);
            this.btnCategorias.Name = "btnCategorias";
            this.btnCategorias.Size = new System.Drawing.Size(406, 73);
            this.btnCategorias.TabIndex = 7;
            this.btnCategorias.Text = "Información de categorías";
            this.btnCategorias.UseVisualStyleBackColor = true;
            this.btnCategorias.Click += new System.EventHandler(this.btnCategorias_Click);
            // 
            // btnVolt
            // 
            this.btnVolt.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnVolt.FlatAppearance.BorderSize = 0;
            this.btnVolt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolt.Location = new System.Drawing.Point(0, 482);
            this.btnVolt.Name = "btnVolt";
            this.btnVolt.Size = new System.Drawing.Size(406, 73);
            this.btnVolt.TabIndex = 6;
            this.btnVolt.Text = "Información de deportes";
            this.btnVolt.UseVisualStyleBackColor = true;
            this.btnVolt.Click += new System.EventHandler(this.btnVolt_Click);
            // 
            // btnDeportista
            // 
            this.btnDeportista.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDeportista.FlatAppearance.BorderSize = 0;
            this.btnDeportista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeportista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeportista.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeportista.Location = new System.Drawing.Point(0, 409);
            this.btnDeportista.Name = "btnDeportista";
            this.btnDeportista.Size = new System.Drawing.Size(406, 73);
            this.btnDeportista.TabIndex = 5;
            this.btnDeportista.Text = "Información de deportistas";
            this.btnDeportista.UseVisualStyleBackColor = true;
            this.btnDeportista.Click += new System.EventHandler(this.btnDeportista_Click);
            // 
            // btnPaises
            // 
            this.btnPaises.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPaises.FlatAppearance.BorderSize = 0;
            this.btnPaises.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPaises.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaises.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPaises.Location = new System.Drawing.Point(0, 336);
            this.btnPaises.Name = "btnPaises";
            this.btnPaises.Size = new System.Drawing.Size(406, 73);
            this.btnPaises.TabIndex = 4;
            this.btnPaises.Text = "Información de paises";
            this.btnPaises.UseVisualStyleBackColor = true;
            this.btnPaises.Click += new System.EventHandler(this.btnPaises_Click);
            // 
            // btnEquipo
            // 
            this.btnEquipo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEquipo.FlatAppearance.BorderSize = 0;
            this.btnEquipo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEquipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEquipo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEquipo.Location = new System.Drawing.Point(0, 263);
            this.btnEquipo.Name = "btnEquipo";
            this.btnEquipo.Size = new System.Drawing.Size(406, 73);
            this.btnEquipo.TabIndex = 3;
            this.btnEquipo.Text = "Equipo";
            this.btnEquipo.UseVisualStyleBackColor = true;
            this.btnEquipo.Click += new System.EventHandler(this.btnEquipo_Click);
            // 
            // btnDeporte
            // 
            this.btnDeporte.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDeporte.FlatAppearance.BorderSize = 0;
            this.btnDeporte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeporte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeporte.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeporte.Location = new System.Drawing.Point(0, 190);
            this.btnDeporte.Name = "btnDeporte";
            this.btnDeporte.Size = new System.Drawing.Size(406, 73);
            this.btnDeporte.TabIndex = 2;
            this.btnDeporte.Text = "Deporte";
            this.btnDeporte.UseVisualStyleBackColor = true;
            this.btnDeporte.Click += new System.EventHandler(this.btnDeporte_Click);
            // 
            // btnCompetidor
            // 
            this.btnCompetidor.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCompetidor.FlatAppearance.BorderSize = 0;
            this.btnCompetidor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCompetidor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompetidor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCompetidor.Location = new System.Drawing.Point(0, 117);
            this.btnCompetidor.Name = "btnCompetidor";
            this.btnCompetidor.Size = new System.Drawing.Size(406, 73);
            this.btnCompetidor.TabIndex = 1;
            this.btnCompetidor.Text = "Competidor";
            this.btnCompetidor.UseVisualStyleBackColor = true;
            this.btnCompetidor.Click += new System.EventHandler(this.btnCompetidor_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(406, 117);
            this.panelLogo.TabIndex = 1;
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.panelTitleBar.Controls.Add(this.lblTitle);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(406, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(1216, 117);
            this.panelTitleBar.TabIndex = 1;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(434, 38);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(291, 38);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Juegos Olímpicos";
            // 
            // panelDesktopPane
            // 
            this.panelDesktopPane.BackColor = System.Drawing.Color.LightGray;
            this.panelDesktopPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktopPane.Location = new System.Drawing.Point(406, 117);
            this.panelDesktopPane.Name = "panelDesktopPane";
            this.panelDesktopPane.Size = new System.Drawing.Size(1216, 706);
            this.panelDesktopPane.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::OlimpicosProject.Properties.Resources.olimpics_games1;
            this.pictureBox1.Location = new System.Drawing.Point(86, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(191, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnRankingP
            // 
            this.btnRankingP.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRankingP.FlatAppearance.BorderSize = 0;
            this.btnRankingP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRankingP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRankingP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRankingP.Location = new System.Drawing.Point(0, 628);
            this.btnRankingP.Name = "btnRankingP";
            this.btnRankingP.Size = new System.Drawing.Size(406, 73);
            this.btnRankingP.TabIndex = 8;
            this.btnRankingP.Text = "Ranking de países";
            this.btnRankingP.UseVisualStyleBackColor = true;
            this.btnRankingP.Click += new System.EventHandler(this.btnRankingP_Click);
            // 
            // btnRankingD
            // 
            this.btnRankingD.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRankingD.FlatAppearance.BorderSize = 0;
            this.btnRankingD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRankingD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRankingD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRankingD.Location = new System.Drawing.Point(0, 701);
            this.btnRankingD.Name = "btnRankingD";
            this.btnRankingD.Size = new System.Drawing.Size(406, 73);
            this.btnRankingD.TabIndex = 9;
            this.btnRankingD.Text = "Ranking de deportistas";
            this.btnRankingD.UseVisualStyleBackColor = true;
            this.btnRankingD.Click += new System.EventHandler(this.btnRankingD_Click);
            // 
            // frmPrincipal
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1622, 823);
            this.Controls.Add(this.panelDesktopPane);
            this.Controls.Add(this.panelTitleBar);
            this.Controls.Add(this.panelMenu);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmPrincipal";
            this.Text = "Juegos Olímpicos";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelTitleBar.ResumeLayout(false);
            this.panelTitleBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnCompetidor;
        private System.Windows.Forms.Button btnCategorias;
        private System.Windows.Forms.Button btnVolt;
        private System.Windows.Forms.Button btnDeportista;
        private System.Windows.Forms.Button btnPaises;
        private System.Windows.Forms.Button btnEquipo;
        private System.Windows.Forms.Button btnDeporte;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panelDesktopPane;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnRankingD;
        private System.Windows.Forms.Button btnRankingP;
    }
}

