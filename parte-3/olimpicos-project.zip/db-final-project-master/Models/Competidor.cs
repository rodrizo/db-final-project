﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OlimpicosProject.Models
{
    public class Competidor
    {
        public int IdCompetidor { get; set; }
        public string Nombre { get; set; }
        public string DPI { get; set; }
        public DateTime Fecha_nacimiento { get; set; }
        public int IdPais { get; set; }
    }
}
