﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OlimpicosProject.Models
{
    public class Marca
    {
        public int IdMarca { get; set; }
        public decimal Puntaje { get; set; }
        public int IdCompetidor { get; set; }
    }
}
