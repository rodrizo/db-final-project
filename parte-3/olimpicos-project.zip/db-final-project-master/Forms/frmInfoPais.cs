﻿using OlimpicosProject.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmInfoPais : Form
    {
        PaisData pData = new PaisData();
        private int Id;

        #region "Obteniendo y llenando combobox de países"
        private void getPaises()
        {
            ComboData cmb = new ComboData();
            cmbPaises.DataSource = cmb.getPaises();
            cmbPaises.DisplayMember = "nombre";
            cmbPaises.ValueMember = "idPais";
        }
        #endregion

        #region "Función encargada de recoger opciones"
        private void getInfo(int id, int option)
        {
            DataSet ds = pData.getPaisInfo(id, option);
            gridPaises.DataSource = ds;
            gridPaises.DataMember = "Pais";
        }
        #endregion

        #region "Función encargada de asignar el idPais"
        private void getData()
        {
            Id = Convert.ToInt32(cmbPaises.SelectedValue);
        }
        #endregion

        public frmInfoPais()
        {
            InitializeComponent();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            getData();
            #region "Medallas y en qué deporte o categoría ha ganado"
            getInfo(Id, 1);
            #endregion
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            getData();
            #region "Deportes y categorías asociados al país"
            getInfo(Id, 2);
            #endregion
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            getData();
            #region "Deportistas y equipos participantes"
            getInfo(Id, 3);
            #endregion
        }

        private void frmInfoPais_Load(object sender, EventArgs e)
        {
            getPaises();
        }
    }
}
