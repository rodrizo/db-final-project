﻿using OlimpicosProject.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmInfoCategorias : Form
    {
        CategoriaData depData = new CategoriaData();
        private int Id;

        #region "Obteniendo y llenando combobox de categorías"
        private void getCategorias()
        {
            ComboData cmb = new ComboData();
            cmbCategorias.DataSource = cmb.getCategorias();
            cmbCategorias.DisplayMember = "nombre";
            cmbCategorias.ValueMember = "idCategoria";
        }
        #endregion

        #region "Función encargada de recoger opciones"
        private void getInfo(int id, int option)
        {
            DataSet ds = depData.getCategoriaInfo(id, option);
            gridCategorias.DataSource = ds;
            gridCategorias.DataMember = "Categoria";
        }
        #endregion

        #region "Función encargada de asignar el idCategoria"
        private void getData()
        {
            Id = Convert.ToInt32(cmbCategorias.SelectedValue);
        }
        #endregion
        public frmInfoCategorias()
        {
            InitializeComponent();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            getData();
            #region "Países participantes en esa categoría"
            getInfo(Id, 1);
            #endregion
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            getData();
            #region "Deportistas participantes en esta categoría"
            getInfo(Id, 2);
            #endregion

        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            getData();
            #region "Ranking de países y medallas obtenidas en esta categoría"
            getInfo(Id, 3);
            #endregion

        }

        private void frmInfoCategorias_Load(object sender, EventArgs e)
        {
            getCategorias();
        }
    }
}
