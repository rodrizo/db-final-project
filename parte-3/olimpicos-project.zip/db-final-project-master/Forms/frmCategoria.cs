﻿using OlimpicosProject.Controllers;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject
{
    public partial class frmCategoria : Form
    {
        Categoria cat = new Categoria();
        CategoriaData catData = new CategoriaData();
        private int Id;

        #region "Llenando grid de categoria"
        private void getCategoria()
        {
            DataSet ds = catData.getCategoria();
            gridCategoria.DataSource = ds;
            gridCategoria.DataMember = "Categoria";
        }
        #endregion

        #region "Obteniendo los datos ingresados en el form"
        private void getData()
        {
            cat.IdCategoria= Id;
            cat.Nombre = txtNombre.Text;
            cat.IdTipo = Convert.ToInt32(cmbTipo.SelectedValue);
            cat.IdDeporte = Convert.ToInt32(cmbDeporte.SelectedValue);
        }
        #endregion

        #region "Obteniendo y llenando combobox de Tipo"
        private void getTipo()
        {
            ComboData cmb = new ComboData();
            cmbTipo.DataSource = cmb.getTipo();
            cmbTipo.DisplayMember = "nombre";
            cmbTipo.ValueMember = "idTipo";
        }
        #endregion

        #region "Obteniendo y llenando combobox de Deporte"
        private void getDeporte()
        {
            ComboData cmb = new ComboData();
            cmbDeporte.DataSource = cmb.getDeporte();
            cmbDeporte.DisplayMember = "nombre";
            cmbDeporte.ValueMember = "idDeporte";
        }
        #endregion

        #region "Limpiando los campos"
        private void cleanFields()
        {
            Id = 0;
            txtNombre.Text = string.Empty;
            cmbTipo.Text = string.Empty;
            cmbDeporte.Text = string.Empty;
            getCategoria();
        }
        #endregion

        public frmCategoria()
        {
            InitializeComponent();
        }

        private void frmCategoria_Load(object sender, EventArgs e)
        {
            getTipo();
            getDeporte();
            getCategoria();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            getData();
            catData.CategoriaCRUD(cat, "C");
            MessageBox.Show("Categria creada con éxito");
            cleanFields();
        }

        private void gridCategoria_DoubleClick(object sender, EventArgs e)
        {
            Id = Convert.ToInt32(gridCategoria.CurrentRow.Cells["Id"].Value.ToString());
            txtNombre.Text = gridCategoria.CurrentRow.Cells["Nombre"].Value.ToString();
            cmbTipo.Text = gridCategoria.CurrentRow.Cells["Tipo"].Value.ToString();
            cmbDeporte.Text = gridCategoria.CurrentRow.Cells["Deporte"].Value.ToString();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó ninguna categoría");
            }
            else
            {
                getData();
                catData.CategoriaCRUD(cat, "U");
                cleanFields();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó ninguna categoría");
            }
            else
            {
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult dg = MessageBox.Show("¿Desea eliminar a esta categoria?\n", "Eliminar Categoría", buttons);
                if (dg == DialogResult.Yes)
                {
                    getData();
                    catData.CategoriaCRUD(cat, "D");
                    cleanFields();
                    MessageBox.Show("La categoría se eliminó con éxito");
                }
                else
                {
                    txtNombre.Focus();
                }

            }

        }

    }
}