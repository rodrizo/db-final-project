﻿using OlimpicosProject.Controllers;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject
{
    public partial class frmDeporte : Form
    {
        Deporte dep = new Deporte();
        DeporteData depData = new DeporteData();
        private int Id;

        #region "Llenando grid de Deporte"
        private void getDeporte()
        {
            DataSet ds = depData.getDeporte();
            gridDeporte.DataSource = ds;
            gridDeporte.DataMember = "Deporte";
        }
        #endregion

        #region "Obteniendo los datos ingresados en el form"
        private void getData()
        {
            dep.IdDeporte = Id;
            dep.Nombre = txtNombre.Text;
           
        }
        #endregion

        #region "Limpiando los campos"
        private void cleanFields()
        {
            Id = 0;
            txtNombre.Text = string.Empty;
            getDeporte();

        }
        #endregion
        public frmDeporte()
        {
            InitializeComponent();
        }

        private void frmDeporte_Load(object sender, EventArgs e)
        {
            getDeporte();
        }


        private void gridDeporte_DoubleClick(object sender, EventArgs e)
        {
            Id = Convert.ToInt32(gridDeporte.CurrentRow.Cells["Id"].Value.ToString());
            txtNombre.Text = gridDeporte.CurrentRow.Cells["Nombre"].Value.ToString();
            
        }

        private void btnCategoria_Click(object sender, EventArgs e)
        {
            frmCategoria frm = new frmCategoria();
            frm.Show();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            getData();
            depData.DeporteCRUD(dep, "C");
            MessageBox.Show("Creado con éxito");
            cleanFields();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó ningún deporte");
            }
            else
            {
                getData();
                depData.DeporteCRUD(dep, "U");
                cleanFields();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó ningún deporte");
            }
            else
            {
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult dg = MessageBox.Show("¿Desea eliminar este registro?\n", "Eliminar Registro", buttons);
                if (dg == DialogResult.Yes)
                {
                    getData();
                    depData.DeporteCRUD(dep, "D");
                    cleanFields();
                    MessageBox.Show("El registro se ha eliminado");
                }
                else
                {
                    txtNombre.Focus();
                }

            }

        }
    }
}