﻿using OlimpicosProject.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    //Creador: Rodney Rizo
    public partial class frmRankingCompetidores : Form
    {
        CompetidorData compData = new CompetidorData();
        private int Id;


        #region "Función encargada de proveer id"
        private void getInfo(int id)
        {
            DataSet ds = compData.getRankingCompetidor(id);
            gridCompetidores.DataSource = ds;
            gridCompetidores.DataMember = "Competidor";
        }
        #endregion
        public frmRankingCompetidores()
        {
            InitializeComponent();
        }


        private void btnOne_Click(object sender, EventArgs e)
        {
            #region "Ranking de competidores"
            getInfo(Id);
            #endregion
        }
    }
}
