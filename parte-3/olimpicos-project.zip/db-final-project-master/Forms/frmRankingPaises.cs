﻿using OlimpicosProject.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    //Creador: Rodney Rizo
    public partial class frmRankingPaises : Form
    {
        PaisData pData = new PaisData();
        private int Id;


        #region "Función encargada de proveer id"
        private void getInfo(int id)
        {
            DataSet ds = pData.getRankingPais(id);
            gridPaises.DataSource = ds;
            gridPaises.DataMember = "Pais";
        }
        #endregion

        public frmRankingPaises()
        {
            InitializeComponent();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            #region "Ranking de países"
            getInfo(Id);
            #endregion
        }

    }
}
