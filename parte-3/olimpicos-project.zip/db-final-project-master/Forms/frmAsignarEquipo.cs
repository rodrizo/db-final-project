﻿using OlimpicosProject.Controllers;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmAsignarEquipo : Form
    {
        CompetidorData data = new CompetidorData();
        Competidor comp = new Competidor();
        

        #region "Obteniendo y llenando combobox de equipos"
        private void getEquipos()
        {
            ComboData cmb = new ComboData();
            cmbEquipos.DataSource = cmb.getEquipos();
            cmbEquipos.DisplayMember = "nombre";
            cmbEquipos.ValueMember = "idEquipo";
        }
        #endregion

        public frmAsignarEquipo(int Id)
        {
            comp.IdCompetidor = Id;
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            int idEquipo = Convert.ToInt32(cmbEquipos.SelectedValue);
            data.asignarEquipo(idEquipo, comp.IdCompetidor);
            MessageBox.Show($"El competidor fue asignado a su equipo.");
            this.Close();
        }

        private void frmAsignarEquipo_Load(object sender, EventArgs e)
        {
            getEquipos();
        }
    }
}
