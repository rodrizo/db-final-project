﻿using OlimpicosProject.Controllers;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmEquipo : Form
    {
        Equipo eq = new Equipo();
        EquipoData eqData = new EquipoData();
        private int Id;

        #region "Llenando grid de equipos"
        private void getEquipos()
        {
            DataSet ds = eqData.getEquipos();
            gridEquipo.DataSource = ds;
            gridEquipo.DataMember = "Equipo";
        }
        #endregion

        #region "Obteniendo los datos ingresados en el form"
        private void getData()
        {
            eq.IdEquipo = Id;
            eq.Nombre = txtName.Text;
            eq.IdPais = Convert.ToInt32(cmbPaises.SelectedValue);
        }
        #endregion

        #region "Obteniendo y llenando combobox de países"
        private void getPaises()
        {
            ComboData cmb = new ComboData();
            cmbPaises.DataSource = cmb.getPaises();
            cmbPaises.DisplayMember = "nombre";
            cmbPaises.ValueMember = "idPais";
        }
        #endregion

        #region "Limpiando los campos"
        private void cleanFields()
        {
            Id = 0;
            txtName.Text = string.Empty;
            cmbPaises.Text = string.Empty;
            getEquipos();
        }
        #endregion

        public frmEquipo()
        {
            InitializeComponent();
        }

        private void gridEquipo_DoubleClick(object sender, EventArgs e)
        {
            Id = Convert.ToInt32(gridEquipo.CurrentRow.Cells["Id"].Value.ToString());
            txtName.Text = gridEquipo.CurrentRow.Cells["Nombre"].Value.ToString();
            cmbPaises.Text = gridEquipo.CurrentRow.Cells["Pais"].Value.ToString();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            getData();
            eqData.EquipoCRUD(eq, "C");
            MessageBox.Show("Equipo creado con éxito");
            cleanFields();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó ningún equipo");
            }
            else
            {
                getData();
                eqData.EquipoCRUD(eq, "U");
                cleanFields();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó ningún equipo");
            }
            else
            {
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult dg = MessageBox.Show("¿Desea eliminar este equipo?\n", "Eliminar Equipo", buttons);
                if (dg == DialogResult.Yes)
                {
                    getData();
                    eqData.EquipoCRUD(eq, "D");
                    cleanFields();
                    MessageBox.Show("El equipo se eliminó con éxito");
                }
                else
                {
                    txtName.Focus();
                }

            }
        }

        private void btnMedalla_Click(object sender, EventArgs e)
        {
            frmAsignarMedalla frm = new frmAsignarMedalla(Id, 1);
            frm.Show();
        }

        private void btnCategoria_Click(object sender, EventArgs e)
        {
            frmAsignarCategoria frm = new frmAsignarCategoria(Id, 1);
            frm.Show();
        }

        private void frmEquipo_Load(object sender, EventArgs e)
        {
            getEquipos();
            getPaises();
        }
    }
}
