﻿using Microsoft.VisualBasic;
using OlimpicosProject.Controllers;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmCompetidor : Form
    {
        Competidor comp = new Competidor();
        CompetidorData compData = new CompetidorData();
        private int Id;

        #region "Llenando grid de competidores"
        private void getCompetidores()
        {
            DataSet ds = compData.getCompetidores();
            gridCompetidores.DataSource = ds;
            gridCompetidores.DataMember = "Competidor";
        }
        #endregion

        #region "Obteniendo los datos ingresados en el form"
        private void getData()
        {
            comp.IdCompetidor = Id;
            comp.Nombre = txtName.Text;
            comp.DPI = txtDpi.Text;
            comp.Fecha_nacimiento = fechaNacimiento.Value;
            comp.IdPais = Convert.ToInt32(cmbPaises.SelectedValue);
        }
        #endregion

        #region "Obteniendo y llenando combobox de países"
        private void getPaises()
        {
            ComboData cmb = new ComboData();
            cmbPaises.DataSource = cmb.getPaises();
            cmbPaises.DisplayMember = "nombre";
            cmbPaises.ValueMember = "idPais";
        }
        #endregion

        #region "Limpiando los campos"
        private void cleanFields()
        {
            Id = 0;
            txtName.Text = string.Empty;
            txtDpi.Text = string.Empty;
            fechaNacimiento.Text = string.Empty;
            cmbPaises.Text = string.Empty;
            getCompetidores();
        }
        #endregion

        public frmCompetidor()
        {
            InitializeComponent();
        }

        private void frmCompetidor_Load(object sender, EventArgs e)
        {
            getCompetidores();
            getPaises();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            getData();
            compData.CompetidorCRUD(comp, "C");
            MessageBox.Show("Competidor creado con éxito");
            cleanFields();
        }

        private void gridCompetidores_DoubleClick(object sender, EventArgs e)
        {
            Id = Convert.ToInt32(gridCompetidores.CurrentRow.Cells["Id"].Value.ToString());
            txtName.Text = gridCompetidores.CurrentRow.Cells["Nombre"].Value.ToString();
            txtDpi.Text = gridCompetidores.CurrentRow.Cells["DPI"].Value.ToString();
            fechaNacimiento.Value = DateTime.Parse(gridCompetidores.CurrentRow.Cells["Fecha de nacimiento"].Value.ToString());
            cmbPaises.Text = gridCompetidores.CurrentRow.Cells["Pais"].Value.ToString();

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó a ningún competidor");
            }
            else
            {
                getData();
                compData.CompetidorCRUD(comp, "U");
                cleanFields();
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó a ningún competidor");
            }
            else
            {
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult dg = MessageBox.Show("¿Desea eliminar a este competidor?\n", "Eliminar Competidor", buttons);
                if (dg == DialogResult.Yes)
                {
                    getData();
                    compData.CompetidorCRUD(comp, "D");
                    cleanFields();
                    MessageBox.Show("El competidor se eliminó con éxito");
                }
                else
                {
                    txtName.Focus();
                }

            }
        }

        private void btnMarca_Click(object sender, EventArgs e)
        {
            if (Id == 0)
            {
                MessageBox.Show("No se seleccionó a ningún competidor");
            }
            else
            {
                string nameComp = txtName.Text;
                string content = Interaction.InputBox($"Ingresa la marca del competidor {nameComp}", "Registrar Marca", "OK", 300, 100);
                if (content != null)
                {
                    decimal puntaje = Convert.ToDecimal(content);
                    int id = Id;
                    compData.insertMarca(puntaje, id);
                    MessageBox.Show($"Se registró la marca del competidor {nameComp}");
                }
            }

        }

        private void btnEquipo_Click(object sender, EventArgs e)
        {
            frmAsignarEquipo frm = new frmAsignarEquipo(Id);
            frm.Show();
        }

        private void btnMedalla_Click(object sender, EventArgs e)
        {
            frmAsignarMedalla frm = new frmAsignarMedalla(Id, 2);
            frm.Show();
        }

        private void btnCategoria_Click(object sender, EventArgs e)
        {
            frmAsignarCategoria frm = new frmAsignarCategoria(Id, 2);
            frm.Show();
        }
    }
}
