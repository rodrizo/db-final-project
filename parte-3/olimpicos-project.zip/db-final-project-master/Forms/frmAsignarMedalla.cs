﻿using OlimpicosProject.Controllers;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmAsignarMedalla : Form
    {
        CompetidorData compData = new CompetidorData();
        EquipoData eqData = new EquipoData();
        Competidor comp = new Competidor();
        Equipo equipo = new Equipo();
        int opt;

        public frmAsignarMedalla(int Id, int option)
        {
            opt = option;

            if (option == 1)
            {
                equipo.IdEquipo = Id;
            }
            else if (option == 2)
            {
                comp.IdCompetidor = Id;
            }
            InitializeComponent();
        }
        private int getMedalla()
        {
            if (rdOro.Checked) return 1;
            if (rdPlata.Checked) return 2;
            if (rdBronce.Checked) return 3;
            return 0;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (opt == 1)
            {
                int tipoMedalla = getMedalla();
                eqData.asignarMedalla(tipoMedalla, equipo.IdEquipo);
                MessageBox.Show($"La medalla fue asignada a los competidores del equipo.");
            }
            else if (opt == 2)
            {
                int tipoMedalla = getMedalla();
                compData.asignarMedalla(tipoMedalla, comp.IdCompetidor);
                MessageBox.Show($"La medalla fue asignada al competidor.");
            }
            this.Close();
        }
    }
}
