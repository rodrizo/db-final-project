﻿namespace OlimpicosProject.Forms
{
    partial class frmAsignarMedalla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdOro = new System.Windows.Forms.RadioButton();
            this.rdPlata = new System.Windows.Forms.RadioButton();
            this.rdBronce = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rdOro
            // 
            this.rdOro.AutoSize = true;
            this.rdOro.Location = new System.Drawing.Point(135, 84);
            this.rdOro.Name = "rdOro";
            this.rdOro.Size = new System.Drawing.Size(60, 24);
            this.rdOro.TabIndex = 0;
            this.rdOro.TabStop = true;
            this.rdOro.Text = "Oro";
            this.rdOro.UseVisualStyleBackColor = true;
            // 
            // rdPlata
            // 
            this.rdPlata.AutoSize = true;
            this.rdPlata.Location = new System.Drawing.Point(223, 84);
            this.rdPlata.Name = "rdPlata";
            this.rdPlata.Size = new System.Drawing.Size(70, 24);
            this.rdPlata.TabIndex = 1;
            this.rdPlata.TabStop = true;
            this.rdPlata.Text = "Plata";
            this.rdPlata.UseVisualStyleBackColor = true;
            // 
            // rdBronce
            // 
            this.rdBronce.AutoSize = true;
            this.rdBronce.Location = new System.Drawing.Point(313, 84);
            this.rdBronce.Name = "rdBronce";
            this.rdBronce.Size = new System.Drawing.Size(85, 24);
            this.rdBronce.TabIndex = 2;
            this.rdBronce.TabStop = true;
            this.rdBronce.Text = "Bronce";
            this.rdBronce.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(113, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(329, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Selecciona medalla a asignar";
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(177, 149);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(183, 41);
            this.btnOk.TabIndex = 24;
            this.btnOk.Text = "Asignar";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // frmMedallaCompetidor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(550, 226);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rdBronce);
            this.Controls.Add(this.rdPlata);
            this.Controls.Add(this.rdOro);
            this.Name = "frmMedallaCompetidor";
            this.Text = "Asignar medalla";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdOro;
        private System.Windows.Forms.RadioButton rdPlata;
        private System.Windows.Forms.RadioButton rdBronce;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnOk;
    }
}