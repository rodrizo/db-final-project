﻿using OlimpicosProject.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmInfoDeportista : Form
    {
        CompetidorData compData = new CompetidorData();
        private int Id;

        #region "Obteniendo y llenando combobox de competidores"
        private void getCompetidor()
        {
            ComboData cmb = new ComboData();
            cmbCompetidor.DataSource = cmb.getCompetidor();
            cmbCompetidor.DisplayMember = "nombre";
            cmbCompetidor.ValueMember = "idCompetidor";
        }
        #endregion

        #region "Función encargada de recoger opciones"
        private void getInfo(int id, int option)
        {
            DataSet ds = compData.getCompetidorInfo(id, option);
            gridCompetidores.DataSource = ds;
            gridCompetidores.DataMember = "Competidor";
        }
        #endregion

        #region "Función encargada de asignar el idPais"
        private void getData()
        {
            Id = Convert.ToInt32(cmbCompetidor.SelectedValue);
        }
        #endregion
        public frmInfoDeportista()
        {
            InitializeComponent();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            getData();
            #region "Datos relevantes del competidor"
            getInfo(Id, 1);
            #endregion
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            getData();
            #region "Deporte y categoria de un competidor"
            getInfo(Id, 2);
            #endregion
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            getData();
            #region "Medallas obtenidas por competidor"
            getInfo(Id, 3);
            #endregion
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            getData();
            #region "Equipos en los que participa el competidor"
            getInfo(Id, 4);
            #endregion

        }

        private void frmInfoDeportista_Load(object sender, EventArgs e)
        {
            getCompetidor();
        }
    }
}
