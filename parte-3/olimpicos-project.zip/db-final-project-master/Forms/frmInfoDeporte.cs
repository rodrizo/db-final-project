﻿using OlimpicosProject.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmInfoDeporte : Form
    {
        DeporteData depData = new DeporteData();
        private int Id;

        #region "Obteniendo y llenando combobox de deportes"
        private void getDeportes()
        {
            ComboData cmb = new ComboData();
            cmbDeportes.DataSource = cmb.getDeporte();
            cmbDeportes.DisplayMember = "nombre";
            cmbDeportes.ValueMember = "idDeporte";
        }
        #endregion

        #region "Función encargada de recoger opciones"
        private void getInfo(int id, int option)
        {
            DataSet ds = depData.getDeporteInfo(id, option);
            gridDeportes.DataSource = ds;
            gridDeportes.DataMember = "Deporte";
        }
        #endregion

        #region "Función encargada de asignar el idDeporte"
        private void getData()
        {
            Id = Convert.ToInt32(cmbDeportes.SelectedValue);
        }
        #endregion
        public frmInfoDeporte()
        {
            InitializeComponent();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            getData();
            #region "Países participantes en ese deporte"
            getInfo(Id, 1);
            #endregion
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            getData();
            #region "Deportistas y equipos participantes"
            getInfo(Id, 2);
            #endregion
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            getData();
            #region "Categorías asociadas"
            getInfo(Id, 3);
            #endregion
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            getData();
            #region "Marcas asociadas a él o a sus categorías"
            getInfo(Id, 4);
            #endregion
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            getData();
            #region "Ranking de países participantes y medallas obtenidas"
            getInfo(Id, 5);
            #endregion

        }

        private void frmInfoDeporte_Load(object sender, EventArgs e)
        {
            getDeportes();
        }
    }
}
