﻿using OlimpicosProject.Controllers;
using OlimpicosProject.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OlimpicosProject.Forms
{
    public partial class frmAsignarCategoria : Form
    {
        CompetidorData compData = new CompetidorData();
        EquipoData eqData = new EquipoData();
        Competidor comp = new Competidor();
        Equipo equipo = new Equipo();
        int opt;


        #region "Obteniendo y llenando combobox de categorías"
        private void getCategorias()
        {
            ComboData cmb = new ComboData();
            cmbCategorias.DataSource = cmb.getCategorias();
            cmbCategorias.DisplayMember = "nombre";
            cmbCategorias.ValueMember = "idCategoria";
        }
        #endregion

        public frmAsignarCategoria(int Id, int option)
        {
            opt = option;

            if (option == 1)
            {
                equipo.IdEquipo = Id;
            }
            else if (option == 2)
            {
                comp.IdCompetidor = Id;
            }
            InitializeComponent();
        }


        private void btnOk_Click(object sender, EventArgs e)
        {
            if (opt == 1)
            {
                int idCategoria = Convert.ToInt32(cmbCategorias.SelectedValue);
                eqData.asignarCategoria(idCategoria, equipo.IdEquipo);
                MessageBox.Show($"La categoría fue asignada al equipo.");
            }
            else if (opt == 2)
            {
                int idCategoria = Convert.ToInt32(cmbCategorias.SelectedValue);
                compData.asignarCategoria(idCategoria, comp.IdCompetidor);
                MessageBox.Show($"La categoría fue asignada al competidor.");
            }
            this.Close();

            this.Close();
        }

        private void frmAsignarCategoria_Load(object sender, EventArgs e)
        {
            getCategorias();
        }
    }
}
